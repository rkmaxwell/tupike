package com.example.tupike;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class GasView extends AppCompatActivity {

    RecyclerView recyclerView,recyclerViewSearch;
    GasViewAdapter gasViewAdapter,gasAdapter;
    List<Gas> gasList;
    List<Gas> gasesList;

    private ProgressBar progressBar;

    private EditText etSearch;
    private ImageView imageViewSearch;

    String keyWordSearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gas_view);

        gasList=new ArrayList<>();
        gasesList=new ArrayList<>();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewGas);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));




        findViewById(R.id.gasViewLayout).requestFocus();
        progressBar=(ProgressBar)findViewById(R.id.progressLoadGas);

        getAvailableGas();

        etSearch=(EditText)findViewById(R.id.search_gas);
        imageViewSearch=(ImageView)findViewById(R.id.imageSearch);


        keyWordSearch=etSearch.getText().toString().trim();

        imageViewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSearchedGas();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.refresh,menu);

        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()){

            case R.id.action_reload:
                getAvailableGas();
                return  true;

            case R.id.action_offline:
                AlertDialog.Builder alertDialog=new AlertDialog.Builder(GasView.this);
                alertDialog.setMessage("Are you sure to switch off network  data?");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                alertDialog.create();
                alertDialog.show();

                return true;

        }
        return super.onOptionsItemSelected(item);

    }

    private void getAvailableGas(){


        final String URLGas="http://192.168.43.182/gas/gasview.php";
        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest= new StringRequest(Request.Method.GET, URLGas, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {

                progressBar.setVisibility(View.GONE);
                try{

                  //  Toast.makeText(GasView.this, s, Toast.LENGTH_SHORT).show();
                    JSONArray gases=new JSONArray(s);

                    for(int i=0;i<gases.length();i++){
                        JSONObject houseObject=gases.getJSONObject(i);

                        int id=houseObject.getInt("id");
                        int status=houseObject.getInt("status");
                        String name=houseObject.getString("name");
                        String location=houseObject.getString("location");
                        double price=houseObject.getDouble("price");
                        double weight=houseObject.getDouble("weight");
                        double rate=houseObject.getDouble("rate");
                        double refillCost=houseObject.getDouble("refillcost");
                        String image=houseObject.getString("photo");
                        String supplier=houseObject.getString("supplier");
                        String sProfile=houseObject.getString("profile");

                           String profile="http://192.168.43.182/gas/profile/"+sProfile;


                        //String place=houseObject.getString("location");

                        String imagePath="http://192.168.43.182/gas/uploads/"+image;
                        String path="http://leaseholder.mabnets.com/android/uploads/"+image;


                        //Toast.makeText(GasView.this, profile, Toast.LENGTH_SHORT).show();

                        Gas gas=new Gas(id,name,supplier,location,price,refillCost,rate,weight,status,imagePath,profile);
                        gasList.add(gas);
                        gasViewAdapter=new GasViewAdapter(GasView.this,gasList);
                        recyclerView.setAdapter(gasViewAdapter);




                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

                progressBar.setVisibility(View.GONE);
                android.support.v7.app.AlertDialog.Builder alertDialog=new android.support.v7.app.AlertDialog.Builder(GasView.this);
                alertDialog.setMessage("Oops! An error occurred, make sure to be connected to the internet");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getAvailableGas();
                    }
                });
                alertDialog.create();
                alertDialog.show();

            }
        });

        Volley.newRequestQueue(GasView.this).add(stringRequest);
    }

    private void getSearchedGas(){

        final String search;
        search=etSearch.getText().toString().trim();
        if(search.equals("")){

            etSearch.requestFocus();
            getAvailableGas();

        }else{

            progressBar.setVisibility(View.VISIBLE);
           // Toast.makeText(GasView.this, etSearch.getText(), Toast.LENGTH_SHORT).show();

            String searchURL="http://192.168.43.182/gas/search.php?q="+search;

            StringRequest stringRequest=new StringRequest(Request.Method.GET, searchURL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    progressBar.setVisibility(View.GONE);

                    String responses = response.trim();
                   // Toast.makeText(GasView.this, responses, Toast.LENGTH_SHORT).show();

                        try {

                            JSONArray gases = new JSONArray(response);

                            int length=gases.length();
                            if(length == 0){
                                AlertDialog.Builder alertDialog=new AlertDialog.Builder(GasView.this);
                                alertDialog.setMessage("Sorry results for your search '"+search +"' were not found.\n"+
                                        "Try out major keywords like gas name");
                                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        dialog.dismiss();
                                    }
                                });

                                alertDialog.setPositiveButton("Go Back", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        getAvailableGas();
                                    }
                                });

                                alertDialog.create();
                                alertDialog.show();
                            }else {
                                for (int i = 0; i < gases.length(); i++) {
                                    JSONObject houseObject = gases.getJSONObject(i);

                                    int id = houseObject.getInt("id");
                                    int status = houseObject.getInt("status");
                                    String name = houseObject.getString("name");
                                    String location = houseObject.getString("location");
                                    double price = houseObject.getDouble("price");
                                    double weight = houseObject.getDouble("weight");
                                    double rate = houseObject.getDouble("rate");
                                    double refillCost = houseObject.getDouble("refillcost");
                                    String image = houseObject.getString("photo");
                                    String sProfile = houseObject.getString("profile");
                                    String supplier = houseObject.getString("supplier");


                                    String profile = "http://192.168.43.182/gas/profile/" + sProfile;


                                    //String place=houseObject.getString("location");

                                    String imagePath = "http://192.168.43.182/gas/uploads/" + image;


                                    //Toast.makeText(GasView.this, imagePath, Toast.LENGTH_SHORT).show();

                                    Gas gas = new Gas(id, name, supplier, location, price, refillCost, rate, weight, status, imagePath, profile);
                                    gasesList.add(gas);
                                    gasAdapter = new GasViewAdapter(GasView.this, gasesList);
                                    recyclerView.setAdapter(gasAdapter);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressBar.setVisibility(View.GONE);
                    android.support.v7.app.AlertDialog.Builder alertDialog=new android.support.v7.app.AlertDialog.Builder(GasView.this);
                    alertDialog.setMessage("Oops! An error occurred, make sure you are  connected to the internet");
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });

                    alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getAvailableGas();
                        }
                    });
                    alertDialog.create();
                    alertDialog.show();

                }
            });

            Volley.newRequestQueue(GasView.this).add(stringRequest);

        }
    }
}
