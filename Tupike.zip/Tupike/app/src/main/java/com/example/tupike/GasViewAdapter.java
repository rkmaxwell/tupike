package com.example.tupike;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

public class GasViewAdapter extends RecyclerView.Adapter<GasViewAdapter.GasViewHolder> {

    public static final String EXTRA_ID="id";
    public static final String EXTRA_PRICE="price";
    public static final String EXTRA_REFILL_PRICE="refill";
    public static final String EXTRA_GAS="gas";
    private Context mCtx;
    List<Gas> gasList;

    public GasViewAdapter(Context mCtx, List<Gas> gasList) {
        this.mCtx = mCtx;
        this.gasList = gasList;
    }

    @NonNull
    @Override
    public GasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.gas_layout,null);
        return new GasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final GasViewHolder gasViewHolder, int i) {
        final Gas gas=gasList.get(i);

        gasViewHolder.textViewName.setText(gas.getName());
        gasViewHolder.textViewPrice.setText("Buy: "+"Ksh "+String.format("%s",gas.getPrice()));
        gasViewHolder.textViewRefill.setText("Refill: "+"Ksh "+String.format("%s",gas.getRefillCost()));
        gasViewHolder.textViewWeight.setText(String.format("%s",gas.getWeight())+"kgs");
        gasViewHolder.textViewSupplier.setText("Supplier: "+gas.getSupplier());

        gasViewHolder.imageViewSupplier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertDialog=new AlertDialog.Builder(mCtx);
                alertDialog.setMessage("Supplier of "+gas.getName() +" is "+
                        gas.getSupplier()+"\n"+" Their area of business operation is currently at"+gas.getSupplierLocation());

                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alertDialog.create();
                alertDialog.show();
            }
        });

        gasViewHolder.textViewSupplier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertDialog=new AlertDialog.Builder(mCtx);
                alertDialog.setMessage("Supplier of "+gas.getName() +" is "+
                        gas.getSupplier()+"\n"+" Their area of business operation is currently at "+gas.getSupplierLocation());

                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alertDialog.create();
                alertDialog.show();
            }
        });

        Glide.with(mCtx)
                .load(gas.getPhoto())
                .into(gasViewHolder.imageViewGas);

        Glide.with(mCtx)
                .load(gas.getSupplierProfile())
                .into(gasViewHolder.imageViewSupplier);

        gasViewHolder.btnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String gasID=String.format("%s",gas.getId());
                //Toast.makeText(mCtx,gasID, Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(mCtx,GasController.class);
                intent.putExtra(EXTRA_ID,gasID);
                intent.putExtra(EXTRA_GAS,gas.getName());
                intent.putExtra(EXTRA_PRICE,gas.getPrice());
                mCtx.startActivity(intent);

            }
        });

        gasViewHolder.btnRefill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String gasID=String.format("%s",gas.getId());
                //Toast.makeText(mCtx,gasID, Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(mCtx,GasRefill.class);
                intent.putExtra(EXTRA_ID,gasID);
                intent.putExtra(EXTRA_GAS,gas.getName());
                intent.putExtra(EXTRA_PRICE,gas.getRefillCost());
                mCtx.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return gasList.size();
    }

    class GasViewHolder extends RecyclerView.ViewHolder{

        ImageView imageViewGas,imageViewSupplier;
        TextView textViewName,textViewPrice,textViewRefill,textViewWeight,textViewSupplier;
        Button btnBuy,btnRefill;
        public GasViewHolder(@NonNull View itemView) {
            super(itemView);


            imageViewGas=(ImageView)itemView.findViewById(R.id.imageGas);
            imageViewSupplier=(ImageView)itemView.findViewById(R.id.imageSupplier);
            textViewName=(TextView)itemView.findViewById(R.id.gasName);
            textViewPrice=(TextView)itemView.findViewById(R.id.gasPrice);
            textViewRefill=(TextView)itemView.findViewById(R.id.gasRefillCost);
            textViewWeight=(TextView)itemView.findViewById(R.id.gasWeight);
            textViewSupplier=(TextView)itemView.findViewById(R.id.gasSupplier);
            btnBuy=(Button)itemView.findViewById(R.id.buttonBuyGas);
            btnRefill=(Button)itemView.findViewById(R.id.buttonRefillGas);
        }
    }
}
