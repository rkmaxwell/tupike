package com.example.tupike;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class GasController extends AppCompatActivity {

    private EditText gasName,gasPrice,gasBuyerName,gasBuyerLocation,gasBuyerPhone;
    private Button buttonBuyGas;
    String id,gas;
    double price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gas_controller);

        findViewById(R.id.buyLayout).requestFocus();

        gasName=(EditText)findViewById(R.id.buyGasName);
        gasPrice=(EditText)findViewById(R.id.buyGasPrice);
        gasBuyerName=(EditText)findViewById(R.id.buyerName);
        gasBuyerLocation=(EditText)findViewById(R.id.buyerLocation);
        gasBuyerPhone=(EditText)findViewById(R.id.buyerPhone);
        buttonBuyGas=(Button)findViewById(R.id.buttonBuy);



        Bundle bundle=getIntent().getExtras();

        if(bundle != null){
            id=bundle.getString("id");
             gas=bundle.getString("gas");
             price=bundle.getDouble("price");

            String gasPrices=String.format("%s",price);

            //Toast.makeText(GasController.this,String.format("%s",price), Toast.LENGTH_SHORT).show();



            gasName.setText(gas);
            gasPrice.setText(gasPrices);
            gasName.setFocusable(false);
            gasPrice.setFocusable(false);




        }


        buttonBuyGas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeGasPurchase();
            }
        });
    }

    private void makeGasPurchase() {

        String cName = gasBuyerName.getText().toString().trim();
        String cLocation = gasBuyerLocation.getText().toString().trim();
        String cPhone = gasBuyerPhone.getText().toString().trim();

        if (TextUtils.isEmpty(cName)) {
            gasBuyerName.setError("Please enter your name");
            gasBuyerName.requestFocus();
        } else if (TextUtils.isEmpty(cLocation)) {
            gasBuyerLocation.setError("Enter your residence, helps in delivery");
            gasBuyerLocation.requestFocus();
        } else if (TextUtils.isEmpty(cPhone)) {
            gasBuyerPhone.setError("Just to make sure you received");
            gasBuyerPhone.requestFocus();
        } else {


            final String URLPost = "http://192.168.43.182/gas/purchase.php";
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URLPost, new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(GasController.this);
                    alertDialog.setMessage(s.trim());
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                            gasBuyerName.setText("");
                            gasBuyerLocation.setText("");
                            gasBuyerPhone.setText("");

                        }
                    });

                    alertDialog.create();
                    alertDialog.show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(GasController.this);
                    alertDialog.setMessage("Some error occurred, try again");
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    alertDialog.create();
                    alertDialog.show();
                }
            }) {


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    String cName = gasBuyerName.getText().toString().trim();
                    String cLocation = gasBuyerLocation.getText().toString().trim();
                    String cPhone = gasBuyerPhone.getText().toString().trim();
                    String amount=String.format("%s",price);
                    Map<String, String> params = new HashMap<>();
                    params.put("gas", id);
                    params.put("customer", cName);
                    params.put("location", cLocation);
                    params.put("price",amount);
                    params.put("phone", cPhone);

                    return params;
                }
            };

            Volley.newRequestQueue(GasController.this).add(stringRequest);
        }
    }
}
