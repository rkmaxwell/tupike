package com.example.tupike;




public class Notice {

    int id;
    String sender,message,date,senderLocation;
    String status;

    public Notice(int id, String sender, String message, String date, String status,String senderLocation) {
        this.id = id;
        this.sender = sender;
        this.message = message;
        this.date = date;
        this.status = status;
        this.senderLocation=senderLocation;
    }

    public String getSenderLocation() {
        return senderLocation;
    }

    public void setSenderLocation(String senderLocation) {
        this.senderLocation = senderLocation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
