package com.example.tupike;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class SupplierRegistration extends AppCompatActivity {

    private EditText fName,lName,phone,email,residence;
    private Button buttonRegister;
    private ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier_registration);

        fName=(EditText)findViewById(R.id.supplierFirstName);
        lName=(EditText)findViewById(R.id.supplierSurname);
        phone=(EditText)findViewById(R.id.supplierPhone);
        email=(EditText)findViewById(R.id.supplierMail);
        residence=(EditText)findViewById(R.id.supplierBusiness);
        buttonRegister=(Button)findViewById(R.id.buttonRegisterSupplier);
        progressBar=(ProgressBar)findViewById(R.id.progressRegistration);


        findViewById(R.id.regLayout).requestFocus();
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerSupplier();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.supplier_info,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.action_toc:
        }
        return super.onOptionsItemSelected(item);
    }

    private void registerSupplier(){


        final String name=fName.getText().toString().trim();
        final String username=lName.getText().toString().trim();
        final String mail=email.getText().toString().trim();
        final String fon=phone.getText().toString().trim();
        final String location=residence.getText().toString().trim();

        if(TextUtils.isEmpty(name)){

            fName.setError("Enter your first name");
            fName.requestFocus();
        }else if(TextUtils.isEmpty(username)){
            lName.setError("Surname required");
            lName.requestFocus();
        }else if(TextUtils.isEmpty(mail)){
            email.setError("Email required, will not be published");
            email.requestFocus();
        }else if(TextUtils.isEmpty(fon)){
            phone.setError("Phone required, will not be published");
            phone.requestFocus();
        }else if(TextUtils.isEmpty(location)){
            residence.setError("Enter area of business operation");
            residence.requestFocus();
        }else{

            progressBar.setVisibility(View.VISIBLE);
            final String URLRegister="http://192.168.43.182/gas/registration.php";


            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLRegister, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    progressBar.setVisibility(View.GONE);

                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(SupplierRegistration.this);
                    alertDialog.setMessage(response.trim());
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            fName.setText("");
                            lName.setText("");
                            phone.setText("");
                            email.setText("");
                            residence.setText("");
                        }
                    });
                    alertDialog.setPositiveButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    alertDialog.create();
                    alertDialog.show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);

                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(SupplierRegistration.this);
                    alertDialog.setMessage("Oops! An error occurred. Make sure to be connected to the internet");
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });
                    alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            registerSupplier();
                        }
                    });

                    alertDialog.create();
                    alertDialog.show();
                }
            }){


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    final String name=fName.getText().toString().trim();
                    final String username=lName.getText().toString().trim();
                    final String mail=email.getText().toString().trim();
                    final String fon=phone.getText().toString().trim();
                    final String location=residence.getText().toString().trim();

                    Map<String,String> params=new HashMap<>();
                    params.put("firstname",name);
                    params.put("surname",username);
                    params.put("phone",fon);
                    params.put("email",mail);
                    params.put("location",location);

                    return  params;
                }
            };

            Volley.newRequestQueue(SupplierRegistration.this).add(stringRequest);
        }

    }
}
