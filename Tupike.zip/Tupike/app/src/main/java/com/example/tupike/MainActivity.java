package com.example.tupike;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;

import java.util.Map;

public class MainActivity extends AppCompatActivity {

  private TextView mTextMessage;

  private Button buttonHelp,buttonRate,buttonFeed,buttonAbout;

  SliderLayout sliderLayout;

    // website to be visited
    static final String SITE_URL = "http://192.168.43.182/gas/about.php";

    private Button buttonGo;

    // Define variables for custom tabs and its builder
    CustomTabsIntent customTabsIntent;
    CustomTabsIntent.Builder intentBuilder;

  private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
          = new BottomNavigationView.OnNavigationItemSelectedListener() {



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
      switch (item.getItemId()) {
        case R.id.navigation_home:


          return true;
        case R.id.navigation_dashboard:

          startActivity(new Intent(MainActivity.this,GasView.class));
          return true;
        case R.id.navigation_notifications:

          startActivity(new Intent(MainActivity.this,Notification.class));
          return true;
      }
      return false;
    }
  };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    Button buttonRegister;
    buttonRegister=(Button)findViewById(R.id.btnRegisterSupplier);

    buttonHelp=(Button)findViewById(R.id.btnHelpLine);
    buttonRate=(Button)findViewById(R.id.btnRate);
    buttonFeed=(Button)findViewById(R.id.btnFeedBack);
    buttonAbout=(Button)findViewById(R.id.btnAbout);


    buttonRegister.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        startActivity(new Intent(MainActivity.this,SupplierRegistration.class));
      }
    });

    mTextMessage = (TextView) findViewById(R.id.message);
    BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
    navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    sliderLayout=(SliderLayout)findViewById(R.id.imageSliderHome);
    sliderLayout.setIndicatorAnimation(IndicatorAnimations.COLOR);
    sliderLayout.setScrollTimeInSec(1);

    setSliderViews();


    //handling about us tab
      buttonGo=(Button)findViewById(R.id.button);

      // Initialize intentBuilder
      intentBuilder = new CustomTabsIntent.Builder();

      // Set toolbar(tab) color of your chrome browser
      intentBuilder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));

      // Define entry and exit animation
      intentBuilder.setExitAnimations(this, R.anim.right_to_left_end, R.anim.left_to_right_end);
      intentBuilder.setStartAnimations(this, R.anim.left_to_right_start, R.anim.right_to_left_start);
      intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));

      // build it by setting up all
      customTabsIntent = intentBuilder.build();



    buttonHelp.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            ButtonClicked();
        }
    });
    buttonRate.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this,FeedBack.class));
        }
    });
      buttonFeed.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              startActivity(new Intent(MainActivity.this,FeedBack.class));
          }
      });
      buttonAbout.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              ButtonClicked();
          }
      });


  }


  private void setSliderViews() {

    for (int i = 0; i <= 3; i++) {

      DefaultSliderView sliderView = new DefaultSliderView(this);

      switch (i) {
        case 0:
          sliderView.setImageUrl("http://192.168.43.182/gas/uploads/GAS-20190619-090308.jpg");
          sliderView.setDescription("Amani Rentals, Nakuru");
          break;
        case 1:
          sliderView.setImageUrl("http://192.168.43.182/gas/uploads/GAS-20190619-090356.jpg");
          break;
        case 2:
          sliderView.setImageUrl("http://192.168.43.182/gas/uploads/GAS-20190619-091917.jpg");
          break;
        case 3:
          sliderView.setImageUrl("http://192.168.43.182/gas/uploads/GAS-20190619-090356.jpg");
          break;
      }

      sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
      sliderView.setDescription("Welcome to Tupike."+"\t"+"Quality gas.");
      final int finalI = i;
      sliderView.setOnSliderClickListener(new SliderView.OnSliderClickListener() {
        @Override
        public void onSliderClick(SliderView sliderView) {
          Toast.makeText(MainActivity.this, (sliderView.getDescription()), Toast.LENGTH_SHORT).show();
        }
      });

      //at last add this view in your layout :
      sliderLayout.addSliderView(sliderView);
    }
  }

  protected void showContact(){


      Intent phoneIntent=new Intent(Intent.ACTION_CALL);
      phoneIntent.setData(Uri.parse("tel:+25413373480"));

      try{

          startActivity(phoneIntent);
          finish();

      }
      catch (Exception e){
          e.printStackTrace();

          Toast.makeText(MainActivity.this, "Call failed, please try again later", Toast.LENGTH_LONG).show();
          //Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
      }
  }
    public void ButtonClicked() {

        // go to website defined above
        customTabsIntent.launchUrl(this, Uri.parse(SITE_URL));

    }
}
