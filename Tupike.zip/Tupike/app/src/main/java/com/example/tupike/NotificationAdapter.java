package com.example.tupike;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder> {

    private Context mCtx;
    List<Notice> noticeList;

    public NotificationAdapter(Context mCtx, List<Notice> noticeList) {
        this.mCtx = mCtx;
        this.noticeList = noticeList;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.notification_layout,null);
        return new NotificationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder notificationViewHolder, int i) {

        final Notice notice=noticeList.get(i);

        notificationViewHolder.textViewSender.setText(notice.getSender());
        notificationViewHolder.textViewMessage.setText(notice.getMessage());
        notificationViewHolder.textViewDate.setText(notice.getDate());
       notificationViewHolder.textViewSenderLocation.setText(notice.getSenderLocation());
    }

    @Override
    public int getItemCount() {
        return noticeList.size();
    }

    class  NotificationViewHolder extends RecyclerView.ViewHolder{

        TextView textViewSender,textViewMessage,textViewDate,textViewStatus,textViewSenderLocation;
        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewSender=(TextView)itemView.findViewById(R.id.tvSender);
            textViewMessage=(TextView)itemView.findViewById(R.id.tvMessage);
            textViewDate=(TextView)itemView.findViewById(R.id.tvDate);
            textViewStatus=(TextView)itemView.findViewById(R.id.tvStatus);
            textViewSenderLocation=(TextView)itemView.findViewById(R.id.tvLocation);

        }
    }

}
