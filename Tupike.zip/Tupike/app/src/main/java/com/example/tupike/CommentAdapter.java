package com.example.tupike;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {

    private Context mCtx;
    private List<Comment> commentList;

    public CommentAdapter(Context mCtx, List<Comment> commentList) {
        this.mCtx = mCtx;
        this.commentList = commentList;
    }

    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.comment_layout,null);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder commentViewHolder, int i) {

        final Comment comment=commentList.get(i);

        commentViewHolder.textViewMessage.setText(comment.getMessage());
        commentViewHolder.textViewSender.setText(comment.getSender());
        commentViewHolder.textViewDate.setText(comment.getDate());
    }

    @Override
    public int getItemCount() {
        return commentList.size();
    }

    class  CommentViewHolder extends RecyclerView.ViewHolder{

        TextView textViewMessage,textViewSender,textViewDate;

        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewMessage=(TextView)itemView.findViewById(R.id.feedMessage);
            textViewSender=(TextView)itemView.findViewById(R.id.feederName);
            textViewDate=(TextView)itemView.findViewById(R.id.feedDate);
        }
    }
}
