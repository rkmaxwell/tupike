package com.example.tupike;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.ColorInt;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FeedBack extends AppCompatActivity {

    private EditText etMessage,etUsername,ratingEmail;
    private Button buttonSend,buttonRate;
    private ProgressBar progressBar;
    private TextView textViewNotification;

    private ImageView imageView1,imageView2,imageView3,imageView4,imageView5;
    private TextView textViewRate;

    RecyclerView recyclerView;
    CommentAdapter commentAdapter;
    List<Comment> commentList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);

        findViewById(R.id.feedBackLayout).requestFocus();

        buttonRate=(Button)findViewById(R.id.btnRateService);
        ratingEmail=(EditText)findViewById(R.id.rateMail);


        imageView1=(ImageView)findViewById(R.id.rate1);
        imageView2=(ImageView)findViewById(R.id.rate2);
        imageView3=(ImageView)findViewById(R.id.rate3);
        imageView4=(ImageView)findViewById(R.id.rate4);
        imageView5=(ImageView)findViewById(R.id.rate5);
        textViewRate=(TextView)findViewById(R.id.tvcustomerRate);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewRate.setText("1");
                imageView1.setColorFilter(888);
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewRate.setText("2");
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewRate.setText("3");
            }
        });
        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewRate.setText("4");
            }
        });
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewRate.setText("5");
            }
        });

        buttonRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRate();
            }
        });


        commentList=new ArrayList<>();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewFeeds);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        etMessage=(EditText)findViewById(R.id.fMessage);
        etUsername=(EditText)findViewById(R.id.username);
        buttonSend=(Button)findViewById(R.id.btnSendFeed);
        progressBar=(ProgressBar)findViewById(R.id.progress_sendFeed);
        textViewNotification=(TextView)findViewById(R.id.tvNotify);

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
        getComments();
    }

    private void sendMessage(){

        final String message=etMessage.getText().toString().trim();
        final String user=etUsername.getText().toString().trim();

        if(TextUtils.isEmpty(user)){
            etUsername.requestFocus();
            etUsername.setError("Enter your name");
        }else if(TextUtils.isEmpty(message)){

            etMessage.requestFocus();
        }else{

            progressBar.setVisibility(View.VISIBLE);
            String URLFeed="http://192.168.43.182/gas/feed.php";

            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLFeed, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    progressBar.setVisibility(View.GONE);

                    Toast.makeText(FeedBack.this, response.trim(), Toast.LENGTH_SHORT).show();
                    String res=response.trim();
                    if(res.equals("Message sent successfully")){
                        etUsername.setText("");
                        etMessage.setText("");
                        startActivity(new Intent(FeedBack.this,FeedBack.class));
                        finish();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                    android.support.v7.app.AlertDialog.Builder alertDialog=new android.support.v7.app.AlertDialog.Builder(FeedBack.this);
                    alertDialog.setMessage("Oops! An error occurred, make sure to be connected to the internet");
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });

                    alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            sendMessage();
                        }
                    });
                    alertDialog.create();
                    alertDialog.show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params=new HashMap<>();
                    params.put("username",user);
                    params.put("message",message);
                    return  params;
                }
            };
            Volley.newRequestQueue(FeedBack.this).add(stringRequest);
        }
    }

    private  void getComments(){

        String URLComments="http://192.168.43.182/gas/fetchfeed.php";

        textViewNotification.setText("Loading..");

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLComments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textViewNotification.setText("");

                if(response.trim().equals("No comments yet")){
                    textViewNotification.setText("No comments yet");
                }else {

                    try {

                        JSONArray comments = new JSONArray(response);

                        for (int i = 0; i < comments.length(); i++) {

                            JSONObject commentObject = comments.getJSONObject(i);

                            int id = commentObject.getInt("id");
                            String message = commentObject.getString("message");
                            String sender = commentObject.getString("sender");
                            String date = commentObject.getString("date");
                            int status = commentObject.getInt("status");

                            Comment comment = new Comment(id, message, sender, date, status);
                            commentList.add(comment);
                            commentAdapter = new CommentAdapter(FeedBack.this, commentList);
                            recyclerView.setAdapter(commentAdapter);

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textViewNotification.setText("");
                android.support.v7.app.AlertDialog.Builder alertDialog=new android.support.v7.app.AlertDialog.Builder(FeedBack.this);
                alertDialog.setMessage("Trouble loading comments, check your internet connection");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getComments();
                    }
                });
                alertDialog.create();
                alertDialog.show();
            }
        });

        Volley.newRequestQueue(FeedBack.this).add(stringRequest);
    }

    private void sendRate(){

        final String rate=textViewRate.getText().toString().trim();
        final String email=ratingEmail.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            ratingEmail.setError("Enter your email");
            ratingEmail.requestFocus();
        }else  if(rate.equals("Your rate") || rate.equals("") || rate.isEmpty()){
            Toast.makeText(FeedBack.this, "Please click your rate", Toast.LENGTH_LONG).show();
        }else{

            String URLRate="http://192.168.43.182/gas/rate.php";
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLRate, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    //Toast.makeText(FeedBack.this, response.trim(), Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(FeedBack.this);
                    alertDialog.setMessage(response.trim());
                    alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            ratingEmail.setText("");
                            textViewRate.setText("Your rate");
                        }
                    });
                    alertDialog.create();
                    alertDialog.show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(FeedBack.this, "Error, Please check your internet connection", Toast.LENGTH_LONG).show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params=new HashMap<>();
                    params.put("email",email);
                    params.put("rate",rate);
                    return  params;
                }
            };
            Volley.newRequestQueue(FeedBack.this).add(stringRequest);
        }
    }
}
