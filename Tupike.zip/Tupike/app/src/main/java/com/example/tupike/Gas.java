package com.example.tupike;

public class Gas {

    int id;
    String name,supplier,supplierLocation;
    double price,refillCost,rate,weight;
    int status;
    String photo;String supplierProfile;

    public Gas(int id, String name, String supplier,String location, double price, double refillCost, double rate, double weight, int status, String photo,String supplierProfile) {
        this.id = id;
        this.name = name;
        this.supplier = supplier;
        this.supplierLocation=location;
        this.price = price;
        this.refillCost = refillCost;
        this.rate = rate;
        this.weight = weight;
        this.status = status;
        this.photo = photo;
        this.supplierProfile=supplierProfile;
    }

    public String getSupplierProfile() {
        return supplierProfile;
    }

    public void setSupplierProfile(String supplierProfile) {
        this.supplierProfile = supplierProfile;
    }

    public String getSupplierLocation() {
        return supplierLocation;
    }

    public void setSupplierLocation(String supplierLocation) {
        this.supplierLocation = supplierLocation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getRefillCost() {
        return refillCost;
    }

    public void setRefillCost(double refillCost) {
        this.refillCost = refillCost;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}

